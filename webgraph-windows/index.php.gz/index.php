<?php
/*  weathergraphs.php v 2.0 for ws3600
 *  Copyright 2004, Kenneth Lavrsen
 *  Copyright 2005, Grzegorz Wisniewski, Sander Eerkes
 *  This program is published under the GNU Public license
 */
?>
<HTML>
<HEAD>
<TITLE>Weather Graphs</TITLE>
</HEAD>
<body bgcolor="honeydew" text="black" link="blue" vlink="purple" alink="red">
<h1>Weather Graphs</h1>
<p>Weather graphs are generated on the fly from data maximum 10 minutes old.</p>
<img src="tempin.php" height=400 width=640>
<br>
<img src="tempout.php" height=400 width=640>
<br>
<img src="dewpoint.php" height=400 width=640>
<br>
<img src="windchill.php" height=400 width=640>
<br>
<img src="humidin.php" height=400 width=640>
<br>
<img src="humidout.php" height=400 width=640>
<br>
<img src="airpressure.php" height=480 width=640>
<br>
<img src="windspeed.php" height=400 width=640>
<br>
<img src="winddir.php" height=400 width=640>
<br>
<img src="rain1h.php" height=400 width=640>
<br>
<img src="rain24h.php" height=400 width=640>
<br>
<img src="raintotal.php" height=400 width=640>
<br>
</BODY>
</HTML>
